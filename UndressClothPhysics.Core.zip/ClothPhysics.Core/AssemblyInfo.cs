﻿using System.Reflection;

[assembly: AssemblyTitle(ClothPhysics.ClothPhysics.Name)]
[assembly: AssemblyDescription("Keyframe sequencing/animation tool for Studio")]
[assembly: AssemblyCompany("https://github.com/IllusionMods/HSPlugins")]
[assembly: AssemblyProduct(ClothPhysics.ClothPhysics.Name)]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyVersion(ClothPhysics.ClothPhysics.Version)]
